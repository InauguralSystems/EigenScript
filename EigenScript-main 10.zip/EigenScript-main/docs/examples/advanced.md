# Advanced Examples

See the [Example Gallery](index.md) for the complete list.

Advanced examples showcasing unique features:

- **interrogatives_showcase.eigs** - Self-awareness
- **self_aware_computation.eigs** - Geometric semantics
- **meta_eval_complete.eigs** - Self-hosting
- **self_simulation.eigs** - Meta-circular evaluation

[View all examples →](index.md)
