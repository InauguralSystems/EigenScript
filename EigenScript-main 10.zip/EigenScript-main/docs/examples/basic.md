# Basic Examples

See the [Example Gallery](index.md) for the complete list.

Basic examples perfect for learning:

- **hello_world.eigs** - Simplest program
- **factorial_simple.eigs** - Basic recursion
- **strings.eigs** - String operations
- **core_operators.eigs** - All operators

[View all examples →](index.md)
