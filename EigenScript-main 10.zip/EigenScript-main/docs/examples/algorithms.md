# Algorithm Examples

See the [Example Gallery](index.md) for the complete list.

Algorithm examples:

- **factorial.eigs** - Recursive factorial
- **if_then_else_complete.eigs** - Conditional logic
- **list_operations.eigs** - List algorithms

[View all examples →](index.md)
