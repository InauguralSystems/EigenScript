"""
Tests for EigenScript LLVM compiler.
"""
