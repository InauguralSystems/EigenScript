"""
Test suite for EigenScript.

This package contains unit tests, integration tests, and property-based tests
for all components of the EigenScript interpreter.
"""
